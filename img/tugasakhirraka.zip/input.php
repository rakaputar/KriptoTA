<?php
    include 'koneksi.php';

    $judul = $_POST['judul'];
    $waktu = $_POST['waktu'];
    $isi = $_POST['isi'];

    $query = mysqli_query($connect, "INSERT INTO berita 
        VALUES('','$judul','$waktu','$isi')") 
        or die(mysqli_error($connect));

    if ($query){
        header("location:homepenerbit.php");
    }else if ($connect->connect_error) {
        die('Maaf koneksi gagal: ' . $connect->connect_error);
    }
?>