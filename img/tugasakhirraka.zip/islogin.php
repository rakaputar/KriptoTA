<?php
//session_start();
function isUserLoggedin()
{
    return isset($_SESSION['usernamepengguna']);
}

function isAdminLoggedin()
{
    return isset($_SESSION['usernamepenerbit']);
}

function redirectToLogin()
{
    if (isUserLoggedin()) {
        header("location:loginuser.php");
    }
    if (isAdminLoggedin()) {
        header("location:loginadmin.php");
    }
    exit();
}

//tangani tombol komen
if (isset($_POST['usernamepengguna'])) {
    if (isUserLoggedIn()) {
    } else {
        // Jika pengguna belum login, arahkan ke halaman login
        redirectToLogin();
    }
}
if (isset($_POST['usernamepenerbit'])) {
    if (isAdminLoggedIn()) {
    } else {
        // Jika pengguna belum login, arahkan ke halaman login
        redirectToLogin();
    }
}
