<?php
    session_start();
    include 'koneksi.php';

    $usernamepenerbit=$_POST['usernamepenerbit'];
    $passwordpenerbit=$_POST['passwordpenerbit'];

    $data = mysqli_query($connect,"select * from penerbit where usernamepenerbit='$usernamepenerbit' and passwordpenerbit='$passwordpenerbit'") 
    or die (mysqli_error($connect));
    
    $cek = mysqli_num_rows($data);
    if($cek > 0){
        $_SESSION['usernamepenerbit'] = $usernamepenerbit;
        $_SESSION['status'] = "login";
        header("location:home.php?nama=$usernamepenerbit");
    }else{
        header("location:loginadmin.php?pesan=gagal");
    }
?> 
