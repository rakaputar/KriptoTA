<?php
session_start();
include 'koneksi.php';
include 'islogin.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berita Gadget</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>

<body class="bodyutama">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <?php
    if (isUserLoggedIn()) {
        $username = $_SESSION['usernamepengguna'];
    }
    if (isAdminLoggedin()) {
        $username = $_SESSION['usernamepenerbit'];
    }
    $id_berita = $_GET['id_berita'];
    $query = mysqli_query($connect, "SELECT * FROM komentar WHERE id_beritakomen = $id_berita");

    ?>

    <div class="naviga">
        <nav class="navbar navbar-expand-lg bg-body-dark border sticky-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="home.php" style: align-center>HOME</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="loginuser.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="loginadmin.php">Penerbit</a>
                        </li>
                        <?php
                        if (isUserLoggedIn() || isAdminLoggedin()) {
                        ?>
                            <li class="nav-item">
                                <a class="nav-link" aria-disabled="true" href="logout.php">Logout</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link disabled" aria-disabled="false" href="logout.php">Logout</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

    <?php
    if (isset($_GET['id_berita']) && !empty($_GET['id_berita'])) {
        $id_berita = $_GET['id_berita'];
        //$inner = mysqli_query($connect, "SELECT berita.*, user.usernamepengguna from berita inner join user on berita.id_berita=id_berita where id_berita=$id_berita");
        $inner = mysqli_query($connect, "SELECT * FROM berita  where id_berita = $id_berita");
        $berita = mysqli_fetch_array($inner);
        if (empty($berita)) {
            echo '<p class="text-warning">Berita tidak ditemukan </p>';
        } else {
    ?>

            <div><br><br>
                <div class="beritadalam">
                    <?php if (isAdminLoggedin()) { ?>
                        <div>
                            <a href="editberita.php?id_berita=<?php echo $data['id_berita']; ?>"><button class="edithapushome">edit</button></a>
                            <a href="hapusberita.php?id_berita=<?php echo $data['id_berita']; ?>"><button class="edithapushome">hapus</button></a>
                        </div><?php } ?>

                    <h2><?php echo $berita['judul']; ?></h2>

                    <p class="waktuberita">
                        <?php echo $berita['waktu']; ?>
                    </p>
                    <p class="isiberita">
                        <?php echo nl2br($berita['isi']); ?>
                    </p>
                </div>
            </div>

            <div class="komentar mb-3">
                <div class="komentardalam">
                    <h3>Komentar</h3>
                    <hr />
                    <div class="bg-light py-2 px-3 rounded">
                        <?php
                        while ($komentar = mysqli_fetch_array($query)) { ?>

                            <div class="col fw-bold">
                                <a href="<?php $reply = $komentar['username'] ?>" class="link-dark" style="text-decoration:none">
                                    @<?php echo $komentar['username']; ?>
                                </a>
                            </div>
                            <div class="col">
                            <?php echo nl2br($komentar['isi']);
                        } ?><br>
                            </div>
                    </div>
                    <hr /> <br>
                    <?php
                    if (isUserLoggedIn() || isAdminLoggedin()) {
                    ?>
                        <form action="komentar.php" method="POST">
                            <div class="mb-3">
                                <div class="col fw-bold">
                                @<?php echo $username; ?>
                                </div>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" cols="60" name="isi"></textarea>
                                <input type="hidden" value="<?php echo $berita['id_berita']; ?>" name="id_berita" />
                            </div>
                            <div class="submitkomen">
                                <button class="kirimkomen">Kirim</button>
                            </div>
                        </form>
                    <?php
                    } else { ?>

                        <div class="mb-3">
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" cols="60" name="isi"></textarea>
                        </div>
                        <div class="submitkomen">
                            <button class="kirimkomen">

                                <?php
                                echo "Login terlebih dahulu.";
                                ?>
                            </button>
                        </div>
            <?php
                    }
                }
            }
            ?>
                </div>
            </div>

            <script src="script.js"></script>
</body>

</html>